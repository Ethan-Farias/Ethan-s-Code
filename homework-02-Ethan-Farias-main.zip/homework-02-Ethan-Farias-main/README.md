[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/pszqw92d)
# DS230-homework-02
Homework 2 for DS230

All work should be completed in this repository.  Please commit early and often.  Please do not make a new branch, instead make all commits to the main.

While not necessary for development, all final code and answers should be in the form of a *single* Jupyter notebook - preferably the same as the assignment.
